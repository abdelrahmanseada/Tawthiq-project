Sample employee photos for the Tawthiq import demo.
Use these file names in the "Photo file name" column of the import template.
Images are re-encoded, stripped of metadata and resized on import.
